# HUB - dokumentacja techniczna (Raspberry Pi 5)

## Cel
HUB (Raspberry Pi 5) skanuje pasywnie reklamy BLE urządzenia `device` i na podstawie odebranych odczytów RSSI od beaconów wyznacza pozycję urządzenia w przestrzeni 2D. Wynik jest publikowany do przeglądarki WWW.

## Składowe projektu (kod)

- `hub/main.py`
  - uruchamia skan BLE oraz serwer WWW (Uvicorn/FastAPI) w jednym procesie
- `hub/ble_scanner.py` (`BleScannerService`)
  - callback do `BleakScanner` na reklamy
  - parsowanie manufacturer data
  - cache RSSI per beacon per urządzenie (TTL)
  - wyznaczanie pozycji i aktualizacja stanu
- `hub/packet_parser.py`
  - konwersja RSSI int8 (signed) i parsowanie payloadu do par `(mac_suffix, rssi)`
  - obsługa wariantów endian `company_id`
- `hub/beacon_map.py` (`BeaconMap`)
  - mapowanie `mac_suffix -> (x,y)` dla 4 beaconów (konfiguracja YAML)
- `hub/positioning.py`
  - szybki algorytm pozycji: ważony centroid na bazie estymacji odległości z RSSI
  - filtr EMA na (x,y)
- `hub/web_app.py` + `web/`
  - serwer WWW (FastAPI) + WebSocket `/ws`
  - `web/index.html`, `web/app.js`, `web/style.css` - canvas + rysowanie mapy i pozycji

## Konfiguracja

- `config/settings.yaml`
  - `company_id`: 16-bit identyfikator z manufacturer data (domyślnie ustawiono `0xFFFF`, zgodnie z `c_device.c`)
  - `path_loss`: parametry modelu RSSI->odległość
    - `tx_power`: referencyjne RSSI (dBm) przy 1 metrze (do kalibracji)
    - `n`: wykładnik tłumienia (zwykle 2.0-2.5)
    - `d_min`: minimalna odległość do stabilizacji wag
  - `position_filter.alpha`: EMA dla pozycji
  - `ble.throttle_ms`: throttling dla identycznych payloadów
  - `ble.beacon_ttl_ms`: TTL cache RSSI per beacon (default 5000ms)
- `config/beacons.yaml`
  - `beacons.suffix -> (corner, x, y)`
  - `suffix` to ostatni bajt MAC beacona (hex, 2 znaki), taki jak wysyła `c_device.c` (czyli `addr->a.val[0]`)

## Protokół BLE: payload `device`

### Źródło (referencja)
W projekcie urządzenie `device` jest implementowane w `c_device.c` (Zephyr). Wysyła dane poprzez `BT_DATA(BT_DATA_MANUFACTURER_DATA, ...)`:

- Wartość `COMPANY_ID` = `0xFFFF`
- Manufacturer payload zawiera:
  1. 2 bajty `company_id` w postaci little-endian w buforze (Zephyr i tak mapuje je do `company_id`)
  2. następnie dla każdego aktywnego beacona pary:
     - `mac_last_byte` (1 bajt)
     - `rssi` (1 bajt, signed int8 zakodowany jako 2s complement, transmitowany jako `uint8_t`)

### Logika po stronie urządzenia
`c_device.c` utrzymuje cache RSSI beaconów:

- `MAX_TRACKED_BEACONS = 5`
- `RSSI_TIMEOUT_MS = 5000`
- `UPDATE_INTERVAL_MS = 1000`
- do payloadu dodaje tylko beacony, dla których `tracked_beacons[i].is_active == true`

### Oznaczenia

- `mac_suffix`: ostatni bajt MAC beacona, hex (2 znaki), np. `89`
- `rssi_int8`: signed int8 w dBm, np. `0xC7` => `-57 dBm`

## Parsowanie payloadu w HUB

Kod: `hub/packet_parser.py`

1. `BleakScanner` dostarcza w `advertisement_data.manufacturer_data` mapę:
   - klucz: `company_id` (16-bit)
   - wartość: `bytes` stanowiące *część danych manufacturer data po stronie wartości* (zwykle bez bajtów samego company_id)

2. `extract_payload(manufacturer_data, company_id)`:
   - próbuje dopasować `company_id` bezpośrednio
   - jeśli nie pasuje, próbuje wariantu swap endian

3. `parse_beacon_payload(payload)` zakłada, że payload ma postać:
   - `[mac_suffix_0][rssi_0][mac_suffix_1][rssi_1]...`
   - długość payloadu musi być parzysta

4. Konwersja RSSI signed int8:
   - wejście jest traktowane jako `unsigned byte` (0..255)
   - jeśli `b >= 128`, wartość jest korygowana: `b - 256` (typowe 2s complement)

5. Zwracany wynik:
   - `dict[str, int]` gdzie klucze to `mac_suffix` w lowercase hex (2 znaki),
     a wartości to RSSI w dBm (signed).

### Uwaga: limit liczby beaconów
Urzadzenie może wysłać do `MAX_TRACKED_BEACONS=5`. HUB pozwala na payload zawierający do 10 par, aby nie odrzucać poprawnych ramek.

## Mapowanie beaconów na współrzędne

Kod: `hub/beacon_map.py`

- `BeaconMap.resolve(suffix)` zwraca `(x, y)` dla beacona o danym `suffix`.
- nieznane suffixy są logowane w trybie ostrzegawczym.
- HUB używa minimum 3 znanych beaconów do policzenia pozycji.

## Algorytm lokalizacji (pozycja)

Kod: `hub/positioning.py`

1. Estymacja odległości z RSSI (model log-distance):

   `d_i = 10 ** ((tx_power - rssi_i) / (10 * n))`

2. Wagi dla centroidu:

   `w_i = 1 / max(d_i, d_min)^2`

3. Ważony centroid:

   `x = sum(w_i * x_i) / sum(w_i)`
   
   `y = sum(w_i * y_i) / sum(w_i)`

4. Filtr EMA:
   - pozycja `(x,y)` jest wygładzana per urządzenie
   - `alpha = position_filter.alpha`

### Odświeżanie
Skaner jest pasywny; algorytm uruchamia się po odebraniu reklamy.
UI aktualizuje się poprzez WebSocket za każdym razem, gdy HUB aktualizuje stan (zmiana wersji).

## Cache RSSI per beacon w HUB

Kod: `hub/ble_scanner.py`

HUB implementuje cache RSSI:

- struktura: `device_address -> (suffix -> (rssi, ts_monotonic))`
- `beacon_ttl_ms` odpowiada za wygaszanie cache
- podczas obliczeń pozycji HUB:
  - bierze wszystkie beacony z cache wciąż świeże (`now - ts <= ttl`)
  - tworzy na ich podstawie zestaw `BeaconReading`
  - liczy pozycję, jeśli `min_beacons=3`

To zwiększa stabilność i odporność na sytuacje, gdy pojedynczy payload z urządzenia zawiera <3 beaconów.

## Web UI / publikacja wyniku

Kod: `hub/web_app.py` i `web/*`

- `GET /` serwuje `web/index.html`
- `GET /api/state` zwraca migawkę stanu (JSON)
- WebSocket `/ws`:
  - wysyła stan po zmianie `state.version` (w praktyce przy każdej aktualizacji stanu)

Canvas rysuje:
- prostokąt obszaru (wg `settings.yaml`)
- 4 beacony (wg `config/beacons.yaml`)
- pozycję urządzenia i ślad (ostatnie N punktów)

## Ograniczenia i wymagania praktyczne

1. BLE/BlueZ:
   - HUB używa `bleak` backendu BlueZ (na Raspbian musi być dostępny DBus i usługa bluez)
2. Kalibracja:
   - parametry `tx_power` i `n` wpływają bezpośrednio na jakość estymacji odległości
3. RSSI jest zaszumione:
   - model distance/RSSI jest aproksymacją, a więc wynik wymaga strojenia i wygładzania

