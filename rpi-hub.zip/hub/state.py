"""Shared HUB state for BLE scanner and web UI."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class DeviceState:
    address: str
    x: float | None = None
    y: float | None = None
    beacon_rssi: dict[str, int] = field(default_factory=dict)
    updated_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "x": self.x,
            "y": self.y,
            "beacon_rssi": self.beacon_rssi,
            "updated_at": self.updated_at,
        }


class HubState:
    def __init__(self) -> None:
        self.lock = asyncio.Lock()
        self.devices: dict[str, DeviceState] = {}
        self.beacons: list[dict[str, Any]] = []
        self.area: dict[str, float] = {"width": 1.0, "height": 1.0}
        self._version = 0

    @property
    def version(self) -> int:
        return self._version

    def bump(self) -> None:
        self._version += 1

    async def snapshot(self) -> dict[str, Any]:
        async with self.lock:
            return {
                "area": self.area,
                "beacons": list(self.beacons),
                "devices": [d.to_dict() for d in self.devices.values()],
                "version": self._version,
                "timestamp": time.time(),
            }
