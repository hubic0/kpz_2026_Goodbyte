"""FastAPI web server with WebSocket live updates."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from hub.state import HubState

logger = logging.getLogger(__name__)

BROADCAST_INTERVAL_S = 0.2


def create_app(hub_state: HubState, project_root: Path) -> FastAPI:
    app = FastAPI(title="BLE Localization HUB")
    web_dir = project_root / "web"

    app.mount("/static", StaticFiles(directory=web_dir), name="static")

    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(web_dir / "index.html")

    @app.get("/api/state")
    async def api_state() -> dict:
        return await hub_state.snapshot()

    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket) -> None:
        await websocket.accept()
        last_version = -1
        try:
            while True:
                snap = await hub_state.snapshot()
                if snap["version"] != last_version:
                    await websocket.send_json(snap)
                    last_version = snap["version"]
                await asyncio.sleep(BROADCAST_INTERVAL_S)
        except WebSocketDisconnect:
            logger.debug("WebSocket client disconnected")
        except Exception:
            logger.exception("WebSocket error")

    return app
