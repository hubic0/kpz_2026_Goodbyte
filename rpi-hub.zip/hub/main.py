"""BLE Localization HUB entry point."""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

import uvicorn
import yaml

from hub.ble_scanner import BleScannerService
from hub.state import HubState
from hub.web_app import create_app

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def load_web_config() -> dict:
    path = PROJECT_ROOT / "config" / "settings.yaml"
    with open(path, encoding="utf-8") as f:
        settings = yaml.safe_load(f) or {}
    return settings.get("web", {})


async def run_ble(scanner: BleScannerService) -> None:
    await scanner.start()
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await scanner.stop()


async def main_async() -> None:
    setup_logging()
    log = logging.getLogger("hub.main")

    hub_state = HubState()
    scanner = BleScannerService(hub_state, PROJECT_ROOT)
    app = create_app(hub_state, PROJECT_ROOT)
    web_cfg = load_web_config()
    host = str(web_cfg.get("host", "0.0.0.0"))
    port = int(web_cfg.get("port", 8080))

    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level="info",
        access_log=False,
    )
    server = uvicorn.Server(config)

    log.info("HUB starting — web UI http://%s:%d", host, port)

    async def run_ble_safe() -> None:
        try:
            await run_ble(scanner)
        except Exception:
            log.exception(
                "BLE scanner failed (is Bluetooth available?). "
                "Web UI will still run."
            )
            while True:
                await asyncio.sleep(3600)

    await asyncio.gather(
        run_ble_safe(),
        server.serve(),
    )


def main() -> None:
    try:
        asyncio.run(main_async())
    except KeyboardInterrupt:
        print("\nHUB stopped.")
        sys.exit(0)


if __name__ == "__main__":
    main()
