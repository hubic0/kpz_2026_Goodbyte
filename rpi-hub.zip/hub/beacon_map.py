"""Load and resolve beacon MAC suffix → 2D position."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BeaconInfo:
    suffix: str
    corner: str
    x: float
    y: float


class BeaconMap:
    def __init__(self, config_path: Path) -> None:
        self._beacons: dict[str, BeaconInfo] = {}
        self._load(config_path)

    def _load(self, path: Path) -> None:
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        raw = data.get("beacons") or {}
        for suffix, info in raw.items():
            key = str(suffix).lower().strip()
            self._beacons[key] = BeaconInfo(
                suffix=key,
                corner=str(info.get("corner", "?")),
                x=float(info["x"]),
                y=float(info["y"]),
            )

        logger.info("Loaded %d beacon mappings from %s", len(self._beacons), path)

    def resolve(self, suffix: str) -> BeaconInfo | None:
        return self._beacons.get(suffix.lower())

    def all_beacons(self) -> list[BeaconInfo]:
        return list(self._beacons.values())

    def warn_unknown(self, suffixes: set[str]) -> None:
        for s in suffixes:
            if s not in self._beacons:
                logger.warning("Unknown beacon MAC suffix in packet: %s", s)
