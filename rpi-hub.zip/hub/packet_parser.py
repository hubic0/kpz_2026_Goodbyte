"""Parse device BLE manufacturer data payload."""

from __future__ import annotations


def rssi_from_byte(b: int) -> int:
    """Convert unsigned byte to signed int8 RSSI in dBm."""
    b &= 0xFF
    return b - 256 if b >= 128 else b


def mac_suffix_from_byte(b: int) -> str:
    """Last byte of beacon MAC as 2-char lowercase hex."""
    return f"{b & 0xFF:02x}"


def parse_beacon_payload(payload: bytes) -> dict[str, int] | None:
    """
    Parse manufacturer data after company ID.

    Payload is alternating (mac_suffix_byte, rssi_byte) pairs.
    Returns dict like {"89": -57, "dc": -56} or None on invalid data.
    """
    if not payload or len(payload) % 2 != 0:
        return None

    result: dict[str, int] = {}
    for i in range(0, len(payload), 2):
        suffix = mac_suffix_from_byte(payload[i])
        rssi = rssi_from_byte(payload[i + 1])
        result[suffix] = rssi

    # Urządzenie może wysyłać do MAX_TRACKED_BEACONS=5 beacony,
    # więc nie zawężamy górnego limitu zbyt agresywnie.
    if not (1 <= len(result) <= 10):
        return None

    return result


def extract_payload(manufacturer_data: dict[int, bytes], company_id: int) -> bytes | None:
    """Get payload for configured company_id, trying LE/BE key variants."""
    if company_id in manufacturer_data:
        return manufacturer_data[company_id]

    alt = ((company_id & 0xFF) << 8) | ((company_id >> 8) & 0xFF)
    if alt in manufacturer_data:
        return manufacturer_data[alt]

    return None
