"""BLE passive scanner using Bleak."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
from pathlib import Path

import yaml
from bleak import BleakScanner
from bleak.backends.device import BLEDevice
from bleak.backends.scanner import AdvertisementData

from hub.beacon_map import BeaconMap
from hub.config_util import parse_int
from hub.packet_parser import extract_payload, parse_beacon_payload
from hub.positioning import (
    BeaconReading,
    PathLossConfig,
    PositionTracker,
    compute_position,
)
from hub.state import DeviceState, HubState

logger = logging.getLogger(__name__)


class BleScannerService:
    def __init__(
        self,
        hub_state: HubState,
        project_root: Path,
    ) -> None:
        self._state = hub_state
        self._root = project_root
        self._loop: asyncio.AbstractEventLoop | None = None
        self._settings = self._load_settings()
        self._beacon_map = BeaconMap(project_root / "config" / "beacons.yaml")
        self._path_loss = PathLossConfig(
            tx_power=float(self._settings["path_loss"]["tx_power"]),
            n=float(self._settings["path_loss"]["n"]),
            d_min=float(self._settings["path_loss"]["d_min"]),
        )
        self._ema_alpha = float(self._settings["position_filter"]["alpha"])
        self._company_id = parse_int(self._settings["company_id"])
        self._throttle_s = float(self._settings["ble"]["throttle_ms"]) / 1000.0
        self._debug = bool(
            self._settings["ble"].get("debug")
            or os.environ.get("BLE_DEBUG", "").lower() in ("1", "true", "yes")
        )
        self._trackers: dict[str, PositionTracker] = {}
        self._last_seen: dict[str, float] = {}
        # Cache RSSI per beacon suffix per device address (for robustness).
        # c_device.c: RSSI_TIMEOUT_MS = 5000.
        self._beacon_rssi_cache: dict[str, dict[str, tuple[int, float]]] = {}
        self._beacon_ttl_s = float(self._settings.get("ble", {}).get("beacon_ttl_ms", 5000)) / 1000.0
        self._scanner: BleakScanner | None = None

        self._init_beacon_snapshot()

    def _load_settings(self) -> dict:
        path = self._root / "config" / "settings.yaml"
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _init_beacon_snapshot(self) -> None:
        area = self._settings.get("area", {})
        self._state.area = {
            "width": float(area.get("width", 1.0)),
            "height": float(area.get("height", 1.0)),
        }
        self._state.beacons = [
            {
                "suffix": b.suffix,
                "corner": b.corner,
                "x": b.x,
                "y": b.y,
            }
            for b in self._beacon_map.all_beacons()
        ]

    def _throttle_key(self, address: str, payload: bytes) -> str:
        return f"{address}:{hashlib.md5(payload, usedforsecurity=False).hexdigest()}"

    def _should_process(self, key: str) -> bool:
        now = time.monotonic()
        last = self._last_seen.get(key, 0.0)
        if now - last < self._throttle_s:
            return False
        self._last_seen[key] = now
        return True

    def _on_detection(
        self,
        device: BLEDevice,
        advertisement_data: AdvertisementData,
    ) -> None:
        now_mono = time.monotonic()
        payload = extract_payload(
            advertisement_data.manufacturer_data,
            self._company_id,
        )
        if payload is None:
            return

        if not self._should_process(self._throttle_key(device.address, payload)):
            return

        beacon_rssi = parse_beacon_payload(payload)
        if beacon_rssi is None:
            if self._debug:
                logger.debug(
                    "Invalid payload from %s: %s",
                    device.address,
                    payload.hex(),
                )
            return

        if self._debug:
            logger.info(
                "Device %s beacons=%s raw=%s",
                device.address,
                beacon_rssi,
                payload.hex(),
            )

        self._beacon_map.warn_unknown(set(beacon_rssi.keys()))

        # Update cache with what we just received.
        dev_cache = self._beacon_rssi_cache.setdefault(device.address, {})
        for suffix, rssi in beacon_rssi.items():
            dev_cache[suffix] = (rssi, now_mono)

        # Build readings from cached (recent) beacons.
        readings: list[BeaconReading] = []
        filtered_beacon_rssi: dict[str, int] = {}
        for suffix, (rssi, ts) in list(dev_cache.items()):
            if now_mono - ts > self._beacon_ttl_s:
                dev_cache.pop(suffix, None)
                continue
            info = self._beacon_map.resolve(suffix)
            if info is None:
                continue
            readings.append(BeaconReading(x=info.x, y=info.y, rssi=rssi))
            filtered_beacon_rssi[suffix] = rssi

        raw_pos = compute_position(readings, self._path_loss, min_beacons=3)

        x: float | None = None
        y: float | None = None
        if raw_pos is not None:
            tracker = self._trackers.setdefault(
                device.address,
                PositionTracker(alpha=self._ema_alpha),
            )
            filtered = tracker.update(raw_pos)
            x = filtered.x
            y = filtered.y

        if self._loop is not None:
            self._loop.create_task(
                self._update_state(
                    device.address,
                    x,
                    y,
                    filtered_beacon_rssi,
                )
            )

    async def _update_state(
        self,
        address: str,
        x: float | None,
        y: float | None,
        beacon_rssi: dict[str, int],
    ) -> None:
        now = time.time()
        async with self._state.lock:
            dev = self._state.devices.get(address)
            if dev is None:
                dev = DeviceState(address=address)
                self._state.devices[address] = dev
            if x is not None:
                dev.x = round(x, 4)
            if y is not None:
                dev.y = round(y, 4)
            dev.beacon_rssi = dict(beacon_rssi)
            dev.updated_at = now
            self._state.bump()

    async def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        logger.info(
            "Starting BLE scan (company_id=0x%04X, throttle=%dms)",
            self._company_id,
            int(self._throttle_s * 1000),
        )
        self._scanner = BleakScanner(detection_callback=self._on_detection)
        await self._scanner.start()
        logger.info("BLE scanner active")

    async def stop(self) -> None:
        if self._scanner:
            await self._scanner.stop()
