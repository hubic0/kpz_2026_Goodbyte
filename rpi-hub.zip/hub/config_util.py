"""Helpers for loading YAML configuration values."""

from __future__ import annotations


def parse_int(value: object, default: int = 0) -> int:
    """Parse int from YAML (supports 0xAAAA hex strings and integers)."""
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value.strip(), 0)
    return default
