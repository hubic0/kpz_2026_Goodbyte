"""Fast RSSI-based 2D positioning."""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class PathLossConfig:
    tx_power: float = -59.0
    n: float = 2.0
    d_min: float = 0.05


@dataclass
class BeaconReading:
    x: float
    y: float
    rssi: int


@dataclass
class Position:
    x: float
    y: float


@dataclass
class PositionTracker:
    """Per-device EMA filter for smoothed position."""

    alpha: float = 0.3
    _filtered: Position | None = field(default=None, repr=False)

    def update(self, raw: Position) -> Position:
        if self._filtered is None:
            self._filtered = Position(raw.x, raw.y)
        else:
            a = self.alpha
            self._filtered = Position(
                a * raw.x + (1 - a) * self._filtered.x,
                a * raw.y + (1 - a) * self._filtered.y,
            )
        return self._filtered


def rssi_to_distance(rssi: int, cfg: PathLossConfig) -> float:
    exponent = (cfg.tx_power - rssi) / (10.0 * cfg.n)
    return 10.0 ** exponent


def compute_position(
    readings: list[BeaconReading],
    cfg: PathLossConfig,
    min_beacons: int = 3,
) -> Position | None:
    """
    Weighted centroid using distance estimates from RSSI.

    Closer beacons (stronger RSSI → smaller distance) get higher weight.
    """
    if len(readings) < min_beacons:
        return None

    sum_w = 0.0
    sum_x = 0.0
    sum_y = 0.0

    for r in readings:
        d = max(rssi_to_distance(r.rssi, cfg), cfg.d_min)
        w = 1.0 / (d * d)
        sum_w += w
        sum_x += w * r.x
        sum_y += w * r.y

    if sum_w <= 0 or not math.isfinite(sum_w):
        return None

    return Position(sum_x / sum_w, sum_y / sum_w)
