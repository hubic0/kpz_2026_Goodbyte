# BLE Localization HUB (Raspberry Pi 5)

System lokalizacji urządzeń w przestrzeni 2D na podstawie sygnałów BLE z 4 beaconów. HUB działa na Raspberry Pi 5 (Raspbian Lite) w trybie obserwatora BLE, oblicza pozycję urządzenia i wyświetla ją na żywo w przeglądarce.

## Jak to działa

1. **4 beacony** w rogach prostokąta (1×1 m) nadają swoje MAC.
2. **Urządzenie (device)** odbiera RSSI od beaconów i wysyła pakiet BLE z danymi producenta (`company_id: 0xFFFF`).
3. **HUB (Raspberry Pi)** skanuje reklamy BLE, parsuje pary `(końcówka MAC, RSSI)` i wyznacza pozycję algorytmem ważonego centroidu.
4. **Serwer WWW** (port 8080) pokazuje mapę z beaconami i pozycją urządzenia w czasie rzeczywistym.

### Format pakietu urządzenia

`device` wysyła manufacturer data zawierające `company_id` oraz następnie powtarzane pary:

- `mac_last_byte` (1 bajt)
- `rssi` jako **signed int8** (1 bajt, 2s complement)

W `c_device.c` w jednym pakiecie może pojawić się do `MAX_TRACKED_BEACONS=5` aktywnych beaconów.

| Bajt | Znaczenie |
|------|-----------|
| `mac_last_byte` | Ostatni bajt (końcówka) MAC beacona (`c_device.c`: `addr->a.val[0]`) |
| `rssi` | RSSI jako **signed int8** (np. `0xC7` → **-57 dBm**, nie 199) |

W kodzie HUB parsuje już wyłącznie payload po `company_id` (pary bajtów). Bleak dostarcza `manufacturer_data[0xFFFF]`.

## Wymagania

- Raspberry Pi 5 z Raspbian Lite
- Adapter Bluetooth (wbudowany)
- Python 3.11+
- Dostęp do grupy `bluetooth`

## Instalacja na Raspbian Lite

### 1. System i Bluetooth

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip bluez libglib2.0-dev
sudo systemctl enable --now bluetooth
sudo usermod -aG bluetooth $USER
```

Wyloguj się i zaloguj ponownie (grupa `bluetooth`).

### 2. Weryfikacja adaptera

```bash
sudo hciconfig hci0 up
bluetoothctl show
```

### 3. Projekt

Skopiuj katalog projektu na Pi (np. `~/szymon`), następnie:

```bash
cd ~/szymon
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 4. Mapowanie beaconów

1. Uruchom HUB z logami debug:

   ```bash
   BLE_DEBUG=1 python -m hub.main
   ```

2. Włącz urządzenie i 4 beacony. W logach zobaczysz końcówki MAC, np. `89`, `dc`.

3. Edytuj [`config/beacons.yaml`](config/beacons.yaml) — przypisz każdą końcówkę do właściwego rogu (TL, TR, BR, BL) i współrzędnych.

4. Wyłącz debug i uruchom normalnie.

### 5. Kalibracja RSSI

W [`config/settings.yaml`](config/settings.yaml):

- `path_loss.tx_power` — RSSI przy odległości 1 m (domyślnie -59 dBm)
- `path_loss.n` — wykładnik tłumienia (zwykle 2.0–2.5)

Ustaw urządzenie w znanym punkcie (np. środek 0.5, 0.5) i dostosuj `tx_power` / `n`, aż punkt na mapie zgadza się z rzeczywistością.

### 6. Uruchomienie

```bash
source .venv/bin/activate
python -m hub.main
```

Otwórz w przeglądarce (z komputera w tej samej sieci LAN):

```
http://<IP_RASPBERRY_PI>:8080
```

Adres IP: `hostname -I`.

## Autostart (systemd)

```bash
sudo cp deploy/hub.service /etc/systemd/system/
# Edytuj ścieżki User i WorkingDirectory w pliku, jeśli potrzeba
sudo systemctl daemon-reload
sudo systemctl enable --now hub
sudo systemctl status hub
journalctl -u hub -f
```

## Konfiguracja

| Plik | Opis |
|------|------|
| [`config/beacons.yaml`](config/beacons.yaml) | Mapowanie końcówki MAC → róg i (x, y) |
| [`config/settings.yaml`](config/settings.yaml) | Wymiary obszaru, company_id, path loss, port WWW |

## Struktura projektu

```
szymon/
├── config/
├── hub/           # logika BLE i pozycjonowania
├── web/           # UI (canvas + WebSocket)
├── deploy/        # jednostka systemd
└── requirements.txt
```

## Rozwiązywanie problemów

| Problem | Rozwiązanie |
|---------|-------------|
| RSSI dodatnie (np. 199) | Sprawdź, czy używasz tego HUB-a — konwersja int8 jest w `packet_parser.rssi_from_byte` |
| Brak pakietów | `BLE_DEBUG=1`, sprawdź `company_id` w settings vs. urządzenie |
| Permission denied (BLE) | `sudo usermod -aG bluetooth $USER`, adapter `hci0 up` |
| Pozycja skacze | Zmniejsz `position_filter.alpha` lub zwiększ `path_loss.d_min` |
| Nieznany beacon w logach | Dodaj suffix do `beacons.yaml` |

## Test parsera (lokalnie, bez BLE)

```bash
python -c "
from hub.packet_parser import rssi_from_byte, parse_beacon_payload
assert rssi_from_byte(0xC7) == -57
assert parse_beacon_payload(bytes([0x89, 0xC7, 0xDC, 0xC8])) == {'89': -57, 'dc': -56}
print('OK')
"
```
