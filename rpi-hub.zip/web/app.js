(function () {
  const canvas = document.getElementById("map");
  const ctx = canvas.getContext("2d");
  const statusEl = document.getElementById("status");
  const areaInfo = document.getElementById("area-info");
  const beaconList = document.getElementById("beacon-list");
  const deviceList = document.getElementById("device-list");

  const TRAIL_LEN = 30;
  const trails = new Map();

  let state = {
    area: { width: 1, height: 1 },
    beacons: [],
    devices: [],
  };

  const COLORS = ["#4fc3f7", "#81c784", "#ffb74d", "#e57373", "#ba68c8"];

  function setStatus(connected) {
    statusEl.textContent = connected ? "Połączono" : "Rozłączono — ponawianie…";
    statusEl.className = "status " + (connected ? "connected" : "disconnected");
  }

  function worldToCanvas(x, y, pad) {
    const w = canvas.width - pad * 2;
    const h = canvas.height - pad * 2;
    const cx = pad + (x / state.area.width) * w;
    const cy = pad + (1 - y / state.area.height) * h;
    return { cx, cy };
  }

  function draw() {
    const pad = 40;
    ctx.fillStyle = "#121a24";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const tl = worldToCanvas(0, state.area.height, pad);
    const br = worldToCanvas(state.area.width, 0, pad);
    const rw = br.cx - tl.cx;
    const rh = br.cy - tl.cy;

    ctx.strokeStyle = "#3d5a80";
    ctx.lineWidth = 2;
    ctx.strokeRect(tl.cx, tl.cy, rw, rh);

    ctx.fillStyle = "#8b9cb3";
    ctx.font = "12px sans-serif";
    ctx.fillText("0,0", tl.cx - 8, br.cy + 18);
    ctx.fillText(
      `${state.area.width},${state.area.height}`,
      br.cx - 30,
      tl.cy - 8
    );

    state.beacons.forEach((b) => {
      const { cx, cy } = worldToCanvas(b.x, b.y, pad);
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fillStyle = "#ff9800";
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.font = "11px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(b.corner, cx, cy - 14);
      ctx.fillText(b.suffix, cx, cy + 4);
      ctx.textAlign = "left";
    });

    state.devices.forEach((dev, i) => {
      if (dev.x == null || dev.y == null) return;

      const color = COLORS[i % COLORS.length];
      let trail = trails.get(dev.address);
      if (!trail) {
        trail = [];
        trails.set(dev.address, trail);
      }
      trail.push({ x: dev.x, y: dev.y });
      if (trail.length > TRAIL_LEN) trail.shift();

      trail.forEach((p, j) => {
        const { cx, cy } = worldToCanvas(p.x, p.y, pad);
        ctx.beginPath();
        ctx.arc(cx, cy, 3, 0, Math.PI * 2);
        ctx.fillStyle =
          color +
          Math.floor((j / trail.length) * 180 + 40)
            .toString(16)
            .padStart(2, "0");
        ctx.fill();
      });

      const { cx, cy } = worldToCanvas(dev.x, dev.y, pad);
      ctx.beginPath();
      ctx.arc(cx, cy, 12, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.stroke();
    });
  }

  function renderPanel() {
    areaInfo.textContent = `${state.area.width} × ${state.area.height} m`;

    beaconList.innerHTML = state.beacons
      .map(
        (b) =>
          `<li><strong>${b.corner}</strong> — suffix <code>${b.suffix}</code> @ (${b.x}, ${b.y})</li>`
      )
      .join("");

    if (!state.devices.length) {
      deviceList.innerHTML = '<p class="muted">Brak danych</p>';
      return;
    }

    deviceList.innerHTML = state.devices
      .map((dev) => {
        const rssiRows = Object.entries(dev.beacon_rssi || {})
          .map(([s, r]) => `<div>beacon ${s}: <strong>${r} dBm</strong></div>`)
          .join("");
        const pos =
          dev.x != null
            ? `(${dev.x.toFixed(3)}, ${dev.y.toFixed(3)}) m`
            : "—";
        return `
          <div class="device-card">
            <div class="addr">${dev.address}</div>
            <div class="pos">${pos}</div>
            <div class="rssi-table">${rssiRows || "—"}</div>
          </div>`;
      })
      .join("");
  }

  function applyState(data) {
    state = data;
    draw();
    renderPanel();
  }

  function connect() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${proto}//${location.host}/ws`);

    ws.onopen = () => setStatus(true);
    ws.onclose = () => {
      setStatus(false);
      setTimeout(connect, 2000);
    };
    ws.onerror = () => ws.close();
    ws.onmessage = (ev) => {
      try {
        applyState(JSON.parse(ev.data));
      } catch (e) {
        console.error(e);
      }
    };
  }

  function resizeCanvas() {
    const wrap = canvas.parentElement;
    const size = Math.min(wrap.clientWidth - 32, 600);
    canvas.width = size;
    canvas.height = size;
    draw();
  }

  window.addEventListener("resize", resizeCanvas);
  resizeCanvas();
  connect();
})();
